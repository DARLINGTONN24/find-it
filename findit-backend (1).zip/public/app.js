let me=null,loc={},marketPage=1,accPage=1,accFilters={};
const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);

// api(): wraps fetch. On a 401 (session expired/not logged in) while we *thought* we were
// logged in, show the session-expired banner instead of failing silently.
async function api(u,o={}){
  const r=await fetch(u,{...o,headers:{...(o.body instanceof FormData?{}:{"Content-Type":"application/json"}),...(o.headers||{})}});
  let d={};try{d=await r.json()}catch{}
  if(r.status===401&&me){sessionExpired()}
  if(!r.ok)throw Error(d.error||"Request failed");
  return d;
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function msg(id,t,ok=true){const e=$("#"+id);e.style.display="block";e.textContent=t;e.style.background=ok?"var(--mint)":"#fff0f0"}
function toast(t){const el=document.createElement("div");el.className="toast";el.textContent=t;document.body.appendChild(el);requestAnimationFrame(()=>el.classList.add("show"));setTimeout(()=>{el.classList.remove("show");setTimeout(()=>el.remove(),250)},2600)}

function authOpen(){if($("#modal"))$("#modal").classList.remove("hide")}
function authClose(){$("#modal").classList.add("hide")}
function authTab(x){$("#login").classList.toggle("hide",x!=="login");$("#login2fa").classList.toggle("hide",x!=="login2fa");$("#register").classList.toggle("hide",x!=="register");$("#forgot").classList.toggle("hide",x!=="forgot");$("#authOut").style.display="none"}

function sessionExpired(){me=null;account();$("#sessionBanner").classList.add("show")}
function dismissSessionBanner(){$("#sessionBanner").classList.remove("show")}

function go(id){
  $$(".page").forEach(x=>x.classList.add("hide"));
  $("#"+id).classList.remove("hide");
  window.scrollTo({top:0,behavior:"smooth"});
  dismissSessionBanner();
  if(id==="market"){marketPage=1;loadMarket(true)}
  if(id==="accommodation"){accPage=1;loadAccommodation(true)}
  if(id==="jobs")loadJobs();
  if(id==="dashboard")loadDash();
  if(id==="admin")loadAdmin();
}
$$("[data-go]").forEach(b=>b.onclick=()=>go(b.dataset.go));

function loginThen(id){if(!me)return authOpen();$("#"+id).classList.remove("hide");$("#"+id).scrollIntoView({behavior:"smooth"})}

function account(){
  if(!me){$("#account").innerHTML='<button class="btn" onclick="authOpen()">Login / Register</button>';return}
  $("#account").innerHTML=`<button onclick="go('dashboard')" class="ghost">Hi, ${esc(me.name)}</button>`+(me.role==="admin"?`<button class="ghost" onclick="go('admin')">Admin</button>`:'')+`<button class="btn" onclick="logout()">Logout</button>`;
}

async function init(){
  try{me=(await api("/api/me")).user}catch(e){me=null}
  account();
  loc=await api("/api/locations");
  populate();
  loadMarket(true);
  loadAccommodation(true);
  loadJobs();
}

async function logout(){await api("/api/logout",{method:"POST"});me=null;account();go("home");toast("Logged out.")}

// Cascading Province(city)->Area->Police-station dropdowns for the "report a found item" form
function populate(){
  const c=$("#city");
  c.innerHTML='<option value="">Choose city</option>'+Object.keys(loc).map(x=>`<option>${x}</option>`).join("");
  c.onchange=()=>{
    const a=$("#area");
    a.innerHTML='<option value="">Choose area</option>'+Object.keys(loc[c.value]||{}).map(x=>`<option>${x}</option>`).join("");
    $("#station").innerHTML='<option value="">Choose station</option>';
  };
  $("#area").onchange=()=>{$("#station").innerHTML=(loc[c.value]?.[$("#area").value]||[]).map(x=>`<option>${x}</option>`).join("")};
}

// --- Password strength meter (used on register form and reset.html) ---
function pwStrength(v){
  const bar=$("#pwBar"),hint=$("#pwHint");
  if(!bar)return;
  let score=0;
  if(v.length>=10)score++;
  if(v.length>=14)score++;
  if(/[A-Z]/.test(v)&&/[a-z]/.test(v))score++;
  if(/[0-9]/.test(v))score++;
  if(/[^A-Za-z0-9]/.test(v))score++;
  const pct=Math.min(100,score*20),colors=['#d33','#d33','#e8a13b','#e8a13b','#087b65','#087b65'];
  bar.style.width=pct+'%';bar.style.background=colors[score];
  hint.textContent=v.length===0?'At least 10 characters':score<=2?'Weak — try adding numbers or symbols':score<=3?'Okay — a little longer is better':'Strong password';
}

// --- Auth forms ---
$("#login").onsubmit=async e=>{
  e.preventDefault();
  try{
    const d=await api("/api/login",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});
    if(d.requires2fa){authTab("login2fa");return}
    me=d.user;authClose();account();toast(`Welcome back, ${me.name}.`);
  }
  catch(x){msg("authOut",x.message,false)}
};
$("#login2fa").onsubmit=async e=>{
  e.preventDefault();
  try{me=(await api("/api/login/2fa",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))})).user;authClose();account();toast(`Welcome back, ${me.name}.`)}
  catch(x){msg("authOut",x.message,false)}
};
$("#register").onsubmit=async e=>{
  e.preventDefault();
  const fd=Object.fromEntries(new FormData(e.target));
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fd.email)){msg("authOut","Please enter a valid email address.",false);return}
  try{me=(await api("/api/register",{method:"POST",body:JSON.stringify(fd)})).user;authClose();account();toast(`Welcome to Find It, ${me.name}.`)}
  catch(x){msg("authOut",x.message,false)}
};
$("#forgot").onsubmit=async e=>{
  e.preventDefault();
  try{
    const d=await api("/api/forgot-password",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});
    // devLink is only present because this demo instance has no email service configured —
    // see server.js comment above /api/forgot-password for how to wire up real email.
    msg("authOut",d.devLink?`${d.message}\n\nDemo mode (no email configured) — your reset link:\n${d.devLink}`:d.message,true);
  }catch(x){msg("authOut",x.message,false)}
};

// --- Lost & Found ---
$("#searchLost").onsubmit=async e=>{
  e.preventDefault();if(!me)return authOpen();
  try{
    const d=await api("/api/lost/search",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});
    msg("lostOut",d.found?`MATCH FOUND\nPickup: ${d.policeStation}, ${d.area}, ${d.city}\nPickup code: ${d.pickupCode}\n${d.appreciationOptional?"A token of appreciation may be offered voluntarily after safe recovery.":""}`:d.message,d.found);
  }catch(x){msg("lostOut",x.message,false)}
};
$("#postLost").onsubmit=async e=>{
  e.preventDefault();if(!me)return authOpen();
  try{const d=await api("/api/lost",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});msg("postLostOut",`Private recovery record created.\nPickup code: ${d.pickupCode}`);e.target.reset()}
  catch(x){msg("postLostOut",x.message,false)}
};

// --- Market ---
function productCard(x){
  const imgs=(x.image_path||"").split(",").filter(Boolean);
  const verifiedBadge=x.sellerVerified?'<span class="badge-trusted">✓ Trusted</span> ':'';
  return `<article class="product">${imgs[0]?`<img src="/api/images/${imgs[0]}" onclick="lightbox('${imgs[0]}')" style="cursor:pointer">`:""}${imgs.length>1?`<div class="thumbs">${imgs.map(i=>`<img src="/api/images/${i}" onclick="lightbox('${i}')">`).join("")}</div>`:""}<div class="body">${x.ad_enabled?'<span class="tag" style="background:#fff3d6;color:#8a6100">FEATURED</span> ':''}<span class="tag">${esc(x.category)}</span><h3>${esc(x.title)}</h3><b>${x.price==null?"Price on request":esc(x.price)+" "+esc(x.currency)}</b><p>${esc(x.description||"")}</p><small>${esc(x.city)} ${esc(x.area||"")} • ${verifiedBadge}${esc(x.seller)}</small></div></article>`;
}
async function loadMarket(reset){
  if(reset){marketPage=1;$("#marketGrid").innerHTML=""}
  const f=$("#filter").value;
  $("#marketGridLoading").classList.remove("hide");
  $("#marketLoadMore").classList.add("hide");
  try{
    const d=await api(`/api/market?page=${marketPage}&limit=24`);
    const rows=f?d.items.filter(x=>x.category===f):d.items;
    $("#marketGridLoading").classList.add("hide");
    if(reset&&rows.length===0){$("#marketGrid").innerHTML='<p class="empty">No approved listings yet. Be the first to post one!</p>';return}
    $("#marketGrid").insertAdjacentHTML("beforeend",rows.map(productCard).join(""));
    if(d.hasMore){$("#marketLoadMore").classList.remove("hide");marketPage++}
  }catch(x){$("#marketGridLoading").classList.add("hide");$("#marketGrid").innerHTML=`<p class="empty">Could not load listings: ${esc(x.message)}</p>`}
}
$("#filter").onchange=()=>loadMarket(true);
$("#marketPost").onsubmit=async e=>{
  e.preventDefault();
  try{const r=await fetch("/api/market",{method:"POST",body:new FormData(e.target)}),d=await r.json();if(!r.ok)throw Error(d.error);msg("marketOut",d.message);e.target.reset();loadMarket(true)}
  catch(x){msg("marketOut",x.message,false)}
};
async function loadMarketMine(){
  if(!me)return;
  const rows=await api("/api/market/mine");
  $("#marketMineList").innerHTML=rows.map(x=>`<div class="mine-row"><span>${esc(x.title)} — ${esc(x.city)}</span><span class="st st-${x.status}">${esc(x.status)}</span></div>`).join("")||'<p class="empty">You have not posted any market listings yet.</p>';
}

// --- Accommodation ---
function accCard(x){
  const imgs=(x.image_path||"").split(",").filter(Boolean);
  const typeLabel={room:"Room",apartment:"Apartment",house:"House",cottage:"Cottage",boarding_house:"Boarding house"}[x.listing_type]||x.listing_type;
  const purposeTag=x.purpose==="seeking"?"SEEKING A PLACE":"FOR RENT";
  const verifiedBadge=x.posterVerified?'<span class="badge-trusted">✓ Trusted</span> ':'';
  return `<article class="product">${imgs[0]?`<img src="/api/images/${imgs[0]}" onclick="lightbox('${imgs[0]}')" style="cursor:pointer">`:""}${imgs.length>1?`<div class="thumbs">${imgs.map(i=>`<img src="/api/images/${i}" onclick="lightbox('${i}')">`).join("")}</div>`:""}<div class="body"><span class="tag">${purposeTag}</span> <span class="tag">${esc(typeLabel)}</span><h3>${esc(x.title)}</h3><b>${x.price==null?"Price on request":esc(x.price)+" "+esc(x.currency)+"/mo"}</b><p>${esc(x.description||"")}</p><small>${esc(x.city)} ${esc(x.area||"")}${x.bedrooms?" • "+x.bedrooms+" bed":""}${x.bathrooms?" • "+x.bathrooms+" bath":""} • ${verifiedBadge}${esc(x.poster)}</small></div></article>`;
}
async function loadAccommodation(reset){
  if(reset){accPage=1;$("#accGrid").innerHTML=""}
  accFilters={purpose:$("#accPurposeFilter").value,listingType:$("#accTypeFilter").value};
  $("#accGridLoading").classList.remove("hide");
  $("#accLoadMore").classList.add("hide");
  try{
    const qs=new URLSearchParams({page:accPage,limit:24,...(accFilters.purpose?{purpose:accFilters.purpose}:{}),...(accFilters.listingType?{listingType:accFilters.listingType}:{})});
    const d=await api(`/api/accommodation?${qs}`);
    $("#accGridLoading").classList.add("hide");
    if(reset&&d.items.length===0){$("#accGrid").innerHTML='<p class="empty">No approved listings yet. Be the first to post one!</p>';return}
    $("#accGrid").insertAdjacentHTML("beforeend",d.items.map(accCard).join(""));
    if(d.items.length===24){$("#accLoadMore").classList.remove("hide");accPage++}
  }catch(x){$("#accGridLoading").classList.add("hide");$("#accGrid").innerHTML=`<p class="empty">Could not load listings: ${esc(x.message)}</p>`}
}
$("#accPurposeFilter").onchange=()=>loadAccommodation(true);
$("#accTypeFilter").onchange=()=>loadAccommodation(true);
$("#accPost").onsubmit=async e=>{
  e.preventDefault();
  try{const r=await fetch("/api/accommodation",{method:"POST",body:new FormData(e.target)}),d=await r.json();if(!r.ok)throw Error(d.error);msg("accOut",d.message);e.target.reset();loadAccommodation(true)}
  catch(x){msg("accOut",x.message,false)}
};
async function loadAccommodationMine(){
  if(!me)return;
  const rows=await api("/api/accommodation/mine");
  $("#accMineList").innerHTML=rows.map(x=>`<div class="mine-row"><span>${esc(x.title)} — ${esc(x.city)}</span><span class="st st-${x.status}">${esc(x.status)}</span></div>`).join("")||'<p class="empty">You have not posted any accommodation listings yet.</p>';
}

// --- Image lightbox (shared by market + accommodation cards) ---
function lightbox(filename){
  const box=document.createElement("div");
  box.className="lightbox";
  box.innerHTML=`<button class="x" onclick="this.parentElement.remove()">×</button><img src="/api/images/${filename}">`;
  box.onclick=(e)=>{if(e.target===box)box.remove()};
  document.body.appendChild(box);
}

// --- Jobs ---
async function loadJobs(){
  $("#jobsGridLoading").classList.remove("hide");
  try{
    const rows=await api("/api/jobs");
    $("#jobsGridLoading").classList.add("hide");
    $("#jobsGrid").innerHTML=rows.map(x=>`<article class="job"><span class="tag">VERIFIED COMPANY</span><h3>${esc(x.title)}</h3><b>${esc(x.company_name)}</b><p>${esc(x.description)}</p><small>${esc(x.city||"Zimbabwe")} ${x.salary?"• "+esc(x.salary):""}</small><br><button class="btn" style="margin-top:12px" onclick="apply(${x.id})">Apply directly — NO FEE</button></article>`).join("")||'<p class="empty">No verified vacancies yet.</p>';
  }catch(x){$("#jobsGridLoading").classList.add("hide");$("#jobsGrid").innerHTML=`<p class="empty">Could not load jobs: ${esc(x.message)}</p>`}
}
async function apply(id){
  if(!me)return authOpen();
  const cover=prompt("Cover letter (optional):")||"";
  try{await api("/api/jobs/"+id+"/apply",{method:"POST",body:JSON.stringify({coverLetter:cover})});toast("Application submitted. No application fee was charged.")}
  catch(x){alert(x.message)}
}
$("#companyPost").onsubmit=async e=>{
  e.preventDefault();
  try{const d=await api("/api/companies",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});msg("companyOut",d.message)}
  catch(x){msg("companyOut",x.message,false)}
};
$("#jobPost").onsubmit=async e=>{
  e.preventDefault();
  try{const d=await api("/api/jobs",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});msg("jobOut",d.message||"Submitted");loadJobs()}
  catch(x){msg("jobOut",x.message,false)}
};

// --- Dashboard ---
function dashTab(name){
  $$(".dashtab").forEach(t=>t.classList.toggle("hide",t.dataset.tab!==name));
  $$("[data-dashtab]").forEach(b=>b.classList.toggle("active",b.dataset.dashtab===name));
  if(name==="security")loadSecurityTab();
}
async function loadDash(){
  if(!me)return authOpen();
  $("#profile").name.value=me.name||"";
  $("#profile").phone.value=me.phone||"";
  $("#profile").city.value=me.city||"";
  $("#profile").bio.value=me.bio||"";
  const n=await api("/api/notifications"),m=await api("/api/messages");
  $("#notifications").innerHTML=n.map(x=>`<div><b>${esc(x.title)}</b><br>${esc(x.body)}</div>`).join("")||"<div>No notifications.</div>";
  $("#messages").innerHTML=m.map(x=>`<div><b>${esc(x.sender_name||"Message")}</b><br>${esc(x.body)}</div>`).join("")||"<div>No messages.</div>";
}
$("#profile").onsubmit=async e=>{
  e.preventDefault();
  try{await api("/api/profile",{method:"PATCH",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});toast("Profile saved.")}
  catch(x){alert(x.message)}
};

// --- Two-factor authentication management (Dashboard > Security tab) ---
async function loadSecurityTab(){
  const statusBox=$("#twofaStatus");
  if(me.totpEnabled){
    statusBox.innerHTML=`<p style="color:var(--green);font-weight:700">✓ Two-factor authentication is enabled.</p><label>Enter your password to disable it<input id="twofaDisablePw" type="password"></label><button class="ghost" onclick="disable2fa()">Disable 2FA</button>`;
  }else{
    statusBox.innerHTML=`<p style="font-size:13px;color:var(--muted)">Two-factor authentication adds a second step at login using an app like Google Authenticator, so your account stays protected even if your password leaks.</p><button class="btn" onclick="start2faSetup()">Enable 2FA</button>`;
  }
  const history=await api("/api/security/login-history");
  $("#loginHistory").innerHTML=history.map(x=>`<div class="mine-row"><span>${x.success?"✅":"❌"} ${esc(x.ip||"unknown IP")} — ${esc((x.user_agent||"unknown device").slice(0,60))}</span><span style="font-size:11px;color:var(--muted)">${new Date(x.created_at).toLocaleString()}</span></div>`).join("")||'<p class="empty">No sign-in history yet.</p>';
}
async function start2faSetup(){
  try{
    const d=await api("/api/2fa/setup",{method:"POST"});
    $("#twofaSetupBox").classList.remove("hide");
    $("#twofaSecretText").textContent=d.secret;
    // Also render the otpauth:// URI as a plain link, since generating a scannable QR code
    // client-side would need an extra library — most people can type the secret in manually,
    // and this keeps the app dependency-light.
    $("#twofaSetupBox").insertAdjacentHTML("beforeend",`<p style="font-size:12px;margin-top:8px"><a href="${d.otpauthUri}">Tap to open directly in an authenticator app (mobile only)</a></p>`);
  }catch(x){msg("twofaOut",x.message,false)}
}
async function confirm2fa(){
  try{
    const d=await api("/api/2fa/confirm",{method:"POST",body:JSON.stringify({token:$("#twofaConfirmCode").value})});
    me.totpEnabled=true;
    $("#twofaBackupCodes").classList.remove("hide");
    $("#twofaBackupCodes").innerHTML=`<p style="font-weight:700">Save these one-time backup codes somewhere safe:</p><p style="font-family:monospace;background:var(--bg);padding:10px;border-radius:8px">${d.backupCodes.join("<br>")}</p><p style="font-size:12px;color:var(--muted)">Each can be used once if you lose access to your authenticator app.</p>`;
    $("#twofaSetupBox").classList.add("hide");
    toast("Two-factor authentication enabled.");
    loadSecurityTab();
  }catch(x){msg("twofaOut",x.message,false)}
}
async function disable2fa(){
  try{
    await api("/api/2fa/disable",{method:"POST",body:JSON.stringify({password:$("#twofaDisablePw").value})});
    me.totpEnabled=false;toast("Two-factor authentication disabled.");loadSecurityTab();
  }catch(x){msg("twofaOut",x.message,false)}
}

// --- Admin ---
function adminTab(name){
  $$(".admintab").forEach(t=>t.classList.toggle("hide",t.dataset.tab!==name));
  $$("[data-admintab]").forEach(b=>b.classList.toggle("active",b.dataset.admintab===name));
  if(name==="security")loadAdminSecurity();
}
async function loadAdmin(){
  if(me?.role!=="admin")return;
  const s=await api("/api/admin/summary");
  const labels={pendingMarket:"Pending market",pendingAccommodation:"Pending accommodation",pendingJobs:"Pending jobs",pendingRecruiters:"Pending recruiters",openReports:"Open reports",users:"Users",lostItemsActive:"Active lost items"};
  $("#adminSummary").innerHTML=Object.entries(s).map(([k,v])=>`<div class="stat"><b>${v}</b>${esc(labels[k]||k)}</div>`).join("");
  const [r,m,a,j,p,u]=await Promise.all([
    api("/api/admin/recruiters"),api("/api/admin/market"),api("/api/admin/accommodation"),
    api("/api/admin/jobs"),api("/api/admin/reports"),api("/api/admin/users")
  ]);
  $("#adminsRecruiters").innerHTML=r.map(x=>`<div><b>${esc(x.company_name)}</b> — ${esc(x.registration_number)}<br>${esc(x.name)} (${esc(x.email)}) • status: ${esc(x.verification_status)}<br><button onclick="moderate('recruiters',${x.id},'verified')">Verify</button> <button onclick="moderate('recruiters',${x.id},'rejected')">Reject</button></div>`).join("")||"<p class='empty'>No recruiter registrations yet.</p>";
  $("#adminsMarket").innerHTML=m.map(x=>`<div><b>${esc(x.title)}</b> — ${esc(x.seller)}, ${esc(x.city)} <button onclick="moderate('market',${x.id},'approved')">Approve</button> <button onclick="moderate('market',${x.id},'rejected')">Reject</button></div>`).join("")||"<p class='empty'>Nothing pending.</p>";
  $("#adminsAccommodation").innerHTML=a.map(x=>`<div><b>${esc(x.title)}</b> — ${esc(x.poster)}, ${esc(x.city)} <button onclick="moderate('accommodation',${x.id},'approved')">Approve</button> <button onclick="moderate('accommodation',${x.id},'rejected')">Reject</button></div>`).join("")||"<p class='empty'>Nothing pending.</p>";
  $("#adminsJobs").innerHTML=j.map(x=>`<div><b>${esc(x.title)}</b> — ${esc(x.company_name)} <button onclick="moderate('jobs',${x.id},'approved')">Approve</button> <button onclick="moderate('jobs',${x.id},'rejected')">Reject</button></div>`).join("")||"<p class='empty'>Nothing pending.</p>";
  $("#adminsReports").innerHTML=p.map(x=>`<div><b>${esc(x.target_type)} #${x.target_id}</b><br>${esc(x.reason)} — reported by ${esc(x.reporter)}<br><button onclick="closeReport(${x.id})">Close</button></div>`).join("")||"<p class='empty'>No open reports.</p>";
  $("#adminsUsers").innerHTML=u.map(x=>`<div><b>${esc(x.name)}</b> (${esc(x.email)}) — ${esc(x.role)}${x.city?" • "+esc(x.city):""}</div>`).join("")||"<p class='empty'>No users yet.</p>";
}
async function loadAdminSecurity(){
  const [locked,events,backups]=await Promise.all([
    api("/api/admin/locked-accounts"),api("/api/admin/security-events"),api("/api/admin/backups")
  ]);
  $("#adminsLocked").innerHTML=locked.map(x=>`<div class="mine-row"><span>${esc(x.name)} (${esc(x.email)}) — ${x.failed_login_count} failed attempts, locked until ${new Date(x.locked_until).toLocaleTimeString()}</span><button class="btn" style="padding:6px 12px;font-size:12px" onclick="unlockAccount(${x.id})">Unlock now</button></div>`).join("")||'<p class="empty">No accounts currently locked.</p>';
  $("#adminsSecurityEvents").innerHTML=events.map(x=>`<div class="mine-row"><span><span class="st st-${x.severity==='warning'?'pending':'approved'}">${esc(x.severity)}</span> ${esc(x.event_type)} ${x.name?'— '+esc(x.name):''} ${x.details?'— '+esc(x.details):''}</span><span style="font-size:11px;color:var(--muted)">${new Date(x.created_at).toLocaleString()}</span></div>`).join("")||'<p class="empty">No security events logged yet.</p>';
  $("#adminsBackups").innerHTML=backups.map(x=>`<div class="mine-row"><span>${esc(x.filename)} — ${(x.size_bytes/1024).toFixed(1)} KB</span><span style="font-size:11px;color:var(--muted)">${new Date(x.created_at).toLocaleString()}</span></div>`).join("")||'<p class="empty">No backups recorded yet.</p>';
}
async function unlockAccount(id){await api("/api/admin/unlock/"+id,{method:"POST"});toast("Account unlocked.");loadAdminSecurity()}
async function triggerBackup(){try{const d=await api("/api/admin/backup-now",{method:"POST"});toast(`Backup created: ${d.filename}`);loadAdminSecurity()}catch(x){alert(x.message)}}
async function moderate(type,id,status){await api(`/api/admin/${type}/${id}`,{method:"POST",body:JSON.stringify({status})});toast(`Updated (${status}).`);loadAdmin()}
async function closeReport(id){await api("/api/admin/reports/"+id,{method:"POST",body:JSON.stringify({status:"closed"})});loadAdmin()}

init();
